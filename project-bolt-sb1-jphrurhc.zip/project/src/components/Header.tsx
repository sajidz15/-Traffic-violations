import React, { useState } from 'react';
import { Camera, Moon, Sun, Upload, BarChart3, FileText } from 'lucide-react';

interface HeaderProps {
  appState: 'upload' | 'analyzing' | 'results';
  onNewAnalysis: () => void;
  uploadedFile: File | null;
  violationsCount: number;
}

export const Header: React.FC<HeaderProps> = ({ 
  appState, 
  onNewAnalysis, 
  uploadedFile,
  violationsCount 
}) => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const getStatusText = () => {
    switch (appState) {
      case 'upload':
        return 'Ready to analyze';
      case 'analyzing':
        return `Analyzing ${uploadedFile?.name || 'video'}...`;
      case 'results':
        return `Analysis complete - ${violationsCount} violations detected`;
      default:
        return '';
    }
  };

  const getStatusIcon = () => {
    switch (appState) {
      case 'upload':
        return <Upload className="w-4 h-4" />;
      case 'analyzing':
        return <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      case 'results':
        return <BarChart3 className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
              <Camera className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                TrafficWatch AI
              </h1>
              <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                {getStatusIcon()}
                <span>{getStatusText()}</span>
              </div>
            </div>
          </div>

          {/* Navigation and Controls */}
          <div className="flex items-center space-x-4">
            {appState === 'results' && (
              <button
                onClick={onNewAnalysis}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                <Upload className="w-4 h-4" />
                <span className="hidden sm:inline">New Analysis</span>
              </button>
            )}

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? (
                <Sun className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              ) : (
                <Moon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};