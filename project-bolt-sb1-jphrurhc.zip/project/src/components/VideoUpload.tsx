import React, { useState, useCallback } from 'react';
import { Upload, Video, AlertCircle, CheckCircle } from 'lucide-react';

interface VideoUploadProps {
  onVideoUpload: (file: File) => void;
  isAnalyzing: boolean;
}

export const VideoUpload: React.FC<VideoUploadProps> = ({ onVideoUpload, isAnalyzing }) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('video/')) {
        setSelectedFile(file);
        onVideoUpload(file);
      }
    }
  }, [onVideoUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      onVideoUpload(file);
    }
  }, [onVideoUpload]);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${
          dragActive
            ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/20'
            : 'border-gray-300 dark:border-gray-600 hover:border-blue-400 dark:hover:border-blue-400'
        } ${isAnalyzing ? 'pointer-events-none opacity-50' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input
          type="file"
          accept="video/*"
          onChange={handleFileSelect}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isAnalyzing}
        />
        
        <div className="space-y-4">
          {selectedFile ? (
            <div className="space-y-3">
              <div className="flex items-center justify-center">
                <CheckCircle className="w-12 h-12 text-green-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Video Selected
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedFile.name} ({(selectedFile.size / (1024 * 1024)).toFixed(1)} MB)
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-center">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                  <Video className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Upload Traffic Surveillance Video
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Drag and drop your video file here, or click to browse
                </p>
              </div>
            </div>
          )}
          
          <div className="flex items-center justify-center space-x-1 text-xs text-gray-500 dark:text-gray-400">
            <AlertCircle className="w-3 h-3" />
            <span>Supports MP4, AVI, MOV formats up to 500MB</span>
          </div>
        </div>
      </div>
    </div>
  );
};