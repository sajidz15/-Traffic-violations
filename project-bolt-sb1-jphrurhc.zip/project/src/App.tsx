import React, { useState } from 'react';
import { VideoUpload } from './components/VideoUpload';
import { AnalysisProgress } from './components/AnalysisProgress';
import { Dashboard } from './components/Dashboard';
import { Violation } from './components/ViolationCard';
import { Header } from './components/Header';
import { generateMockViolations } from './utils/mockData';
import { Camera, Shield, Brain, Zap } from 'lucide-react';

type AppState = 'upload' | 'analyzing' | 'results';

function App() {
  const [appState, setAppState] = useState<AppState>('upload');
  const [violations, setViolations] = useState<Violation[]>([]);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleVideoUpload = (file: File) => {
    setUploadedFile(file);
    setAppState('analyzing');
  };

  const handleAnalysisComplete = () => {
    // Simulate AI analysis results
    const mockViolations = generateMockViolations();
    setViolations(mockViolations);
    setAppState('results');
  };

  const handleNewAnalysis = () => {
    setAppState('upload');
    setViolations([]);
    setUploadedFile(null);
  };

  const renderContent = () => {
    switch (appState) {
      case 'upload':
        return (
          <div className="space-y-12">
            {/* Hero Section */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full">
                  <Camera className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-gray-100">
                AI Traffic Surveillance
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
                Advanced AI-powered analysis to detect traffic violations including red light jumping, 
                wrong-way driving, lane violations, and overspeeding with automatic license plate recognition.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
                    <Shield className="w-6 h-6 text-red-600 dark:text-red-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Violation Detection</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Automatically detects red light violations, wrong-way driving, and lane infractions
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                    <Brain className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">AI Recognition</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Advanced neural networks for accurate license plate recognition and vehicle tracking
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                    <Zap className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Real-time Analysis</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Fast processing with detailed timestamp and location data for each violation
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                    <Camera className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Evidence Capture</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  High-quality frame capture and comprehensive reporting for legal documentation
                </p>
              </div>
            </div>

            {/* Upload Section */}
            <VideoUpload onVideoUpload={handleVideoUpload} isAnalyzing={false} />
          </div>
        );
      case 'analyzing':
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
            <AnalysisProgress isAnalyzing={true} onAnalysisComplete={handleAnalysisComplete} />
          </div>
        );
      case 'results':
        return <Dashboard violations={violations} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <Header 
        appState={appState} 
        onNewAnalysis={handleNewAnalysis}
        uploadedFile={uploadedFile}
        violationsCount={violations.length}
      />
      
      <main className="container mx-auto px-4 py-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;